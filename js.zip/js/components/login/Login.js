import React, { Component } from 'react';
import { Image,View } from "react-native";
import { 
	Container, Content, Header,
	Form, Item, Input, Label,
	Body,Card, CardItem,
	Button,Text,H1,H2,H3 
	} from 'native-base';
import { Col, Row, Grid } from "react-native-easy-grid";
import styles from "./style_login";
import { Field, reduxForm } from "redux-form";
class Login extends Component {
  render() {
    return (
      <Container style={styles.bgpage}>
	  	<Content>
			<View style={styles.form_logo}>
				<Image source={require("../../../images/logo.png")} style={{width:150,height:150}}/>
			</View>
			<Form style={styles.form_input}>
				<Card>
					<CardItem style={styles.form_card}>
						<Body>
							<Text style={styles.text_title}>Welcome, please login</Text>
							<Item rounded style={styles.input_text}>
								<Input  placeholder='Username'/>
							</Item>
							<Item rounded style={styles.input_text}>
								<Input  placeholder='Password'/>
							</Item>
							<Text style={{color:'white',marginBottom:10}}>Forgot password</Text>
							<Button medium rounded 
								style={styles.form_button}
								onPress={() => this.props.navigation.navigate("Home")}>
								<Text>Login</Text>
							</Button>
						</Body>
					</CardItem>
				</Card>
			</Form>
		</Content>
      </Container>
    );
  }
}
const LoginSwag = reduxForm(
  {
    form: "test"
  }
)(Login);
LoginSwag.navigationOptions = {
  header: null
};
export default LoginSwag;