import React, { Component } from "react";
import { TouchableOpacity,View,Image } from "react-native";
import { connect } from "react-redux";
import DrawBar from "../DrawBar";
import { DrawerNavigator, NavigationActions } from "react-navigation";
import {
  Container,
  Header,
  Footer,
  Title,
  Content,
  Text,
  Button,
  Icon,
  Left,
  Body,Card, CardItem,
  Right,Badge,List,ListItem
} from "native-base";
import { Grid, Row,Col } from "react-native-easy-grid";
import LinearGradient from 'react-native-linear-gradient';
import { setIndex } from "../../actions/list";
import { openDrawer } from "../../actions/drawer";
import styles from "./styles";

class Layanan extends Component {
	static navigationOptions = {
		header: null
	};
	render() {
	var items = [
	{jenis: 'ATK',title:'Request barang',content: 'Buku'},
	]
    return (
		<Container style={styles.bgpage}>
			<Header style={styles.head}>
				<Left>
					<Button transparent onPress={() => this.props.navigation.goBack()}>
						<Icon name="ios-arrow-back" />
					</Button>
				</Left>
				<Body>
					<Title>Request</Title>
				</Body>
				<Right />
			</Header>
			<Content>
				<Grid style={{justifyContent: 'center', alignItems: 'center',backgroundColor:'#fff',marginBottom:10}}>
					<Col style={{padding:20}}>
						<List dataArray={items}
							renderRow={(item) =>
								<ListItem>
									<Grid>
										<Row>
											<Grid>
												<Col>
													<View style={{alignSelf: 'flex-start',}}>
														<Text style={{fontSize:20}}>{item.jenis}</Text>
													</View>
												</Col>
											</Grid>
										</Row>
										<Row>
											<View style={{alignSelf: 'flex-start',}}>
												<Text>Title:{item.title}</Text>
											</View>
										</Row>
										<Row>
											<View style={{alignSelf: 'flex-start',}}>
												<Text>Content:{item.content}</Text>
											</View>
										</Row>
									</Grid>
								</ListItem>
							}>
						</List>
					</Col>
				</Grid>
			</Content>
			<Footer style={styles.head}>
				<Body style={{alignSelf: 'flex-start',padding:15}}>
					<Title style={{fontSize:10}}>Pengajuan Layanan Umum</Title>
				</Body>
				<Right>
					<Button transparent onPress={() => this.props.navigation.navigate("Inputlayanan")}>
						<Icon name="ios-arrow-forward" style={{color:'white',fontSize:40}}/>
					</Button>
				</Right>
			</Footer>
		</Container>
		);
	}
}
export default Layanan;