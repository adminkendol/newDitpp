import React, { Component } from "react";
import { TouchableOpacity,View,Image,Picker } from "react-native";
import { connect } from "react-redux";
import DrawBar from "../DrawBar";
import { DrawerNavigator, NavigationActions } from "react-navigation";
import {
  Container,
  Header,
  Footer,
  Title,
  Content,
  Text,
  Button,
  Icon,Label,
  Left,Form,Input,Item,
  Body,Card, CardItem,
  Right,Badge,List,ListItem
} from "native-base";
import { Grid, Row,Col } from "react-native-easy-grid";
import LinearGradient from 'react-native-linear-gradient';
import DatePicker from 'react-native-datepicker'
import { setIndex } from "../../actions/list";
import { openDrawer } from "../../actions/drawer";
import styles from "./styles";

class Inputcuti extends Component {
	static navigationOptions = {
		header: null
	};
	constructor(props) {
		super(props);
		this.state = {
			PickerValueHolder : '',
			date:"2018-02-01"
		};
		
	}
	GetSelectedPickerItem=()=>{
		Alert.alert(this.state.PickerValueHolder);
	}

	render() {
	var listCuti=[{"id":"1","nama_cuti":"Cuti Tahunan","pengurangan":"1"},{"id":"2","nama_cuti":"Cuti Besar","pengurangan":"0"},{"id":"3","nama_cuti":"Cuti Sakit","pengurangan":"0"},{"id":"4","nama_cuti":"Cuti Bersalin","pengurangan":"0"},{"id":"5","nama_cuti":"Cuti Karena Alasan Penting","pengurangan":"0"},{"id":"6","nama_cuti":"Keterangan Lain-lain","pengurangan":"0"}];
    return (
		<Container style={styles.bgpage}>
			<Header style={styles.head}>
				<Left>
					<Button transparent onPress={() => this.props.navigation.goBack()}>
						<Icon name="ios-arrow-back" />
					</Button>
				</Left>
				<Body>
					<Title>Pengajuan Cuti</Title>
				</Body>
				<Right />
			</Header>
			<Content>
				<Grid style={styles.margin_bottom}>
					<Col style={{padding:10}}>
						<View style={{justifyContent: 'center', alignItems: 'center',backgroundColor:'#fff',marginBottom:20,padding:10}}>
							<Grid>
								<Col style={{width:35}}><Icon name='md-warning' style={{color:'orange',fontSize:30}}/></Col>
								<Col><Text style={{fontSize:20}}>Remaining</Text></Col>
								<Col>
									<View style={{alignSelf: 'flex-end',}}>
										<Button small primary><Text style={{fontSize:20}}>12</Text></Button>
									</View>
								</Col>
							</Grid>
						</View>
						<View style={{justifyContent: 'center', alignItems: 'center',backgroundColor:'#fff',marginBottom:20,padding:10}}>
							<Grid>
								<Col>
									<Form>
										<Picker
											mode="dropdown"
											selectedValue={this.state.PickerValueHolder}
											onValueChange={(itemValue, itemIndex) => this.setState({PickerValueHolder: itemValue})} >
											{listCuti.map((item, index) => {
												return (< Picker.Item label={item.nama_cuti} value={item.id} key={index} />);
											})}
										</Picker>
										<Grid style={{padding:10}}>
											<Col><Text style={{fontSize:20}}>Mulai</Text></Col>
											<Col>
												<View style={{alignSelf: 'flex-end',}}>
													<DatePicker
														style={{width: 200}}
														date={this.state.date}
														mode="date"
														placeholder="select date"
														format="YYYY-MM-DD"
														confirmBtnText="Confirm"
														cancelBtnText="Cancel"
														customStyles={{
															dateIcon: {
																position: 'absolute',
																left: 0,
																top: 4,
																marginLeft: 0
															},
															dateInput: {
																marginLeft: 36
															}
														}}
														onDateChange={(date) => {this.setState({date: date})}}
													/>
												</View>
											</Col>
										</Grid>
										<Grid style={{padding:10}}>
											<Col><Text style={{fontSize:20}}>Selesai</Text></Col>
											<Col>
												<View style={{alignSelf: 'flex-end',}}>
													<DatePicker
														style={{width: 200}}
														date={this.state.date}
														mode="date"
														placeholder="select date"
														format="YYYY-MM-DD"
														confirmBtnText="Confirm"
														cancelBtnText="Cancel"
														customStyles={{
															dateIcon: {
																position: 'absolute',
																left: 0,
																top: 4,
																marginLeft: 0
															},
															dateInput: {
																marginLeft: 36
															}
														}}
														onDateChange={(date) => {this.setState({date: date})}}
													/>
												</View>
											</Col>
										</Grid>
										<Item floatingLabel last>
											<Label>Alamat</Label>
											<Input />
										</Item>
										<Button medium rounded 
											style={{width: '100%',marginTop:20,flex: 1,justifyContent: 'center', alignItems: 'center'}}>
											<Text>Submit</Text>
										</Button>
									</Form>
								</Col>
							</Grid>
						</View>
					</Col>
				</Grid>
				
			</Content>
		</Container>
		);
	}
}
export default Inputcuti;