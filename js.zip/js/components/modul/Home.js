import React, { Component } from "react";
import { TouchableOpacity,View,Image } from "react-native";
import { connect } from "react-redux";
import BlankPage2 from "../blankPage2";
import Kampret from "../blankPage2";
import DrawBar from "../DrawBar";
import Dashboard from "./Dashboard";
import Cuti from "./Cuti";
import Layanan from "./Layanan";
import Profile from "./Profile";
import { DrawerNavigator, NavigationActions } from "react-navigation";
import {
  Container,
  Header,
  Title,
  Content,
  Text,
  Button,
  Icon,
  Left,
  Body,Card, CardItem,
  Right,Badge
} from "native-base";
import { Grid, Row,Col } from "react-native-easy-grid";

import { setIndex } from "../../actions/list";
import { openDrawer } from "../../actions/drawer";
import styles from "./styles";

class Home extends Component {
	static navigationOptions = {
		header: null
	};
	render() {
    return (
		<Container style={styles.bgpage}>
			<Header style={styles.head}>
				<Left>
					<Button
						transparent
						onPress={() => DrawerNav.navigate("DrawerOpen")}>
						<Icon active name="menu" />
					</Button>
				</Left>
				<Body>
					<Title>Home</Title>
				</Body>
				<Right>
					<Button
						transparent
						onPress={() => {
							DrawerNav.dispatch(
								NavigationActions.reset({
									index: 0,
									actions: [NavigationActions.navigate({ routeName: "Home" })]
								})
							);
							DrawerNav.goBack();
						}}>
						<Icon active name="power" />
					</Button>
				</Right>
			</Header>
			<Content>
				<Grid>
					<Row>
						<View style={styles.form_logo}>
							<Image source={require("../../../images/logo.png")} style={{width:150,height:150}}/>
						</View>
					</Row>
					<Row>
						<View style={styles.label_home}>
							<Text>Release Beta 21 Desember 2017</Text>
						</View>
					</Row>
				</Grid>
				<Grid style={styles.margin_bottom}>
					<Col style={styles.margin_right}>
						<View style={styles.box_white}>
							<Grid style={styles.center}>
								<Col style={{marginLeft:30}}><Icon name='md-information-circle' style={{color:'#3e626e',fontSize:50}}/></Col>
								<Col><Text style={{fontSize:15}}>Info</Text></Col>
								<Col><Button small primary><Text style={{fontSize:15}}>0</Text></Button></Col>
							</Grid>
						</View>
					</Col>
					<Col style={styles.margin_left}>
						<View style={styles.box_white}>
							<Grid style={styles.center}>
								<Col style={{marginLeft:30}}><Icon name='md-phone-portrait' style={{color:'#3e626e',fontSize:50}}/></Col>
								<Col><Text style={{fontSize:15}}>Notif</Text></Col>
								<Col><Button small primary><Text style={{fontSize:15}}>0</Text></Button></Col>
							</Grid>
						</View>
					</Col>
				</Grid>
				<Grid style={styles.margin_bottom}>
					<Col>
						<TouchableOpacity onPress={() => this.props.navigation.navigate("Cuti")} style={styles.box_white_sec}>
							<Grid style={{paddingLeft:25}}>
								<Col style={{width:30}}><Icon name='ios-calendar-outline' style={{color:'#3e626e'}}/></Col>
								<Col><Text style={{fontSize:15}}>Cuti</Text></Col>
							</Grid>
							<Grid style={{padding:20,flex:0}}>
								<Col>
									<View style={styles.box_green}>
										<View style={styles.center}>
											<Text style={{fontSize:15,color:'white'}}>12</Text>
											<Text style={{fontSize:15,color:'white'}}>Total</Text>
										</View>
									</View>
								</Col>
								<Col>
									<View style={styles.box_blue}>
										<View style={styles.center}>
											<Text style={{fontSize:15,color:'white'}}>0</Text>
											<Text style={{fontSize:15,color:'white'}}>Terpakai</Text>
										</View>
									</View>
								</Col>
								<Col>
									<View style={styles.box_red}>
										<View style={styles.center}>
											<Text style={{fontSize:15,color:'white'}}>12</Text>
											<Text style={{fontSize:15,color:'white'}}>Sisa</Text>
										</View>
									</View>
								</Col>
							</Grid>
						</TouchableOpacity>
					</Col>
				</Grid>
				<Grid>
					<Col>
						<TouchableOpacity style={styles.box_white_sec} onPress={() => this.props.navigation.navigate("Absensi")}>
							<Grid style={{paddingLeft:25}}>
								<Col style={{width:30}}><Icon name='md-calendar' style={{color:'#3e626e'}}/></Col>
								<Col><Text style={{fontSize:15}}>Kehadiran</Text></Col>
							</Grid>
							<Grid style={{padding:20,flex:0}}>
								<Col>
									<View style={styles.box_green}>
										<View style={styles.center}>
											<Text style={{fontSize:15,color:'white'}}>2</Text>
											<Text style={{fontSize:15,color:'white'}}>Hadir</Text>
										</View>
									</View>
								</Col>
								<Col>
									<View style={styles.box_green_a}>
										<View style={styles.center}>
											<Text style={{fontSize:15,color:'white'}}>1</Text>
											<Text style={{fontSize:15,color:'white'}}>Total</Text>
										</View>
									</View>
								</Col>
								<Col>
									<View style={styles.box_red}>
										<View style={styles.center}>
											<Text style={{fontSize:15,color:'white'}}>0</Text>
											<Text style={{fontSize:15,color:'white'}}>Tidak hadir</Text>
										</View>
									</View>
								</Col>
							</Grid>
						</TouchableOpacity>
					</Col>
				</Grid>
			</Content>
		</Container>
		);
	}
}
function bindAction(dispatch) {
  return {
    setIndex: index => dispatch(setIndex(index)),
    openDrawer: () => dispatch(openDrawer())
  };
}
const mapStateToProps = state => ({
  name: state.user.name,
  list: state.list.list
});
const HomeSwagger = connect(mapStateToProps, bindAction)(Home);
const DrawNav = DrawerNavigator(
  {
    Home: { screen: HomeSwagger },
    Dashboard: { screen: Dashboard },
	Cuti: { screen: Cuti },
	Layanan: { screen: Layanan },
	Profile: { screen: Profile },
  },
  {
    contentComponent: props => <DrawBar {...props} />
  }
);
const DrawerNav = null;
DrawNav.navigationOptions = ({ navigation }) => {
  DrawerNav = navigation;
  return {
    header: null
  };
};
export default DrawNav;