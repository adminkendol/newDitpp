import React, { Component } from "react";
import { TouchableOpacity,View,Image,Picker } from "react-native";
import { connect } from "react-redux";
import DrawBar from "../DrawBar";
import { DrawerNavigator, NavigationActions } from "react-navigation";
import {
  Container,
  Header,
  Footer,
  Title,
  Content,
  Text,
  Button,
  Icon,Label,Spinner,
  Left,Form,Input,Item,
  Body,Card, CardItem,
  Right,Badge,List,ListItem
} from "native-base";
import { Grid, Row,Col } from "react-native-easy-grid";
import LinearGradient from 'react-native-linear-gradient';
import DatePicker from 'react-native-datepicker'
import { setIndex } from "../../actions/list";
import { openDrawer } from "../../actions/drawer";
import styles from "./styles";

class Inputlayanan extends Component {
	static navigationOptions = {
		header: null
	};
	constructor(props) {
		super(props);
		this.state = {
			PickerValueHolder : '',
			date:"2018-02-01",
			isLoading: true,
		};
		
	}
	GetSelectedPickerItem=()=>{
		Alert.alert(this.state.PickerValueHolder);
	}
	componentWillMount() {
		fetch("http://ditpitalebar.com/api/v1/employee/sar/", {
			method: 'GET',
			headers: {
				'Accept': 'application/json',
				'Content-Type': 'application/json',

			},
			
		})
		.then((response) => response.json())
		.then((responseJson) => {
			console.log(responseJson.response);
			var res=responseJson.response;
			this.setState({isLoading: false,hasil:res}, function() {
			});
		})
		.catch((error) => {
			console.error("ERROT==>",error);
		});
	}
	render() {
	console.log("REST OK==>",this.state.hasil);
	var listJenis=this.state.hasil;
	/*var listJenis=[{id:"1",name:"Peminjaman Aset Kendaraan",show_date:"0"},
			{id:"2",name:"ATK",show_date:"0"},{id:"3",name:"BMN",show_date:"0"},
			{id:"4",name:"Transportasi",show_date:"1"}];*/
	if (this.state.isLoading) {
      return (
        <Container style={styles.bgpage}>
			<Header style={styles.head}>
				<Left>
					<Button transparent onPress={() => this.props.navigation.goBack()}>
						<Icon name="ios-arrow-back" />
					</Button>
				</Left>
				<Body>
					<Title>Request</Title>
				</Body>
				<Right />
			</Header>
			<Content>
				<Grid style={{justifyContent: 'center', alignItems: 'center',backgroundColor:'#47656d',marginTop:'50%'}}>
					<Col style={{padding:20,width:250}}>
						<Spinner color='white' />
					</Col>
					<Col>
						<View style={{alignSelf: 'flex-start',}}>
							<Text style={{color:'white',fontSize:20}}>Please wait ... </Text>
						</View>
					</Col>
				</Grid>
			</Content>
        </Container>
      );
    }
    return (
		<Container style={styles.bgpage}>
			<Header style={styles.head}>
				<Left>
					<Button transparent onPress={() => this.props.navigation.goBack()}>
						<Icon name="ios-arrow-back" />
					</Button>
				</Left>
				<Body>
					<Title>Request</Title>
				</Body>
				<Right />
			</Header>
			<Content>
				<Grid style={styles.margin_bottom}>
					<Col style={{padding:10}}>
						<View style={{justifyContent: 'center', alignItems: 'center',backgroundColor:'#fff',marginBottom:20,padding:10}}>
							<Grid>
								<Col>
									<Form>
										<Picker
											mode="dropdown"
											selectedValue={this.state.PickerValueHolder}
											onValueChange={(itemValue, itemIndex) => this.setState({PickerValueHolder: itemValue})} >
											{listJenis.map((item, index) => {
												return (< Picker.Item label={item.name} value={item.id} key={index} />);
											})}
										</Picker>
										<Item floatingLabel last>
											<Label>Title</Label>
											<Input />
										</Item>
										<Item floatingLabel last>
											<Label>Content</Label>
											<Input />
										</Item>
										<Button medium rounded 
											style={{width: '100%',marginTop:20,flex: 1,justifyContent: 'center', alignItems: 'center'}}>
											<Text>Submit</Text>
										</Button>
									</Form>
								</Col>
							</Grid>
						</View>
					</Col>
				</Grid>
				
			</Content>
		</Container>
		);
	}
}
export default Inputlayanan;