import React, { Component } from "react";
import { TouchableOpacity,View,Image } from "react-native";
import { connect } from "react-redux";
import DrawBar from "../DrawBar";
import { DrawerNavigator, NavigationActions } from "react-navigation";
import {
  Container,
  Header,
  Footer,
  Title,
  Content,
  Text,
  Button,
  Icon,
  Left,Fab,
  Body,Card, CardItem,
  Right,Badge,List,ListItem
} from "native-base";
import { Grid, Row,Col } from "react-native-easy-grid";
import LinearGradient from 'react-native-linear-gradient';
import { setIndex } from "../../actions/list";
import { openDrawer } from "../../actions/drawer";
import styles from "./styles";

class Cuti extends Component {
	static navigationOptions = {
		header: null
	};
	
	render() {
	var items = ['Simon Mignolet','Nathaniel Clyne','Dejan Lovren','Mama Sakho','Emre Can','Dejan Lovren','Mama Sakho','Emre Can'];
    return (
		<Container style={styles.bgpage}>
			<Header style={styles.head}>
				<Left>
					<Button transparent onPress={() => this.props.navigation.goBack()}>
						<Icon name="ios-arrow-back" />
					</Button>
				</Left>
				<Body>
					<Title>Cuti</Title>
				</Body>
				<Right />
			</Header>
			<Content>
				<Grid style={styles.margin_bottom}>
					<Col style={{padding:20}}>
						<Card>
							<CardItem style={{backgroundColor:'#105870'}}>
								<Body>
									<View style={{flex: 1,  justifyContent: 'center', alignItems: 'center',backgroundColor:'#fff',marginBottom:20,padding:20}}>
									<Grid style={{justifyContent: 'center', alignItems: 'center',backgroundColor:'#fff',marginBottom:10}}>
										<Col><Text style={{fontSize:15}}>Jatah cuti</Text></Col>
										<Col>
											<View style={{alignSelf: 'flex-end',}}>
												<Button small primary><Text style={{fontSize:15}}>12</Text></Button>
											</View>
										</Col>
									</Grid>
									<Grid style={{justifyContent: 'center', alignItems: 'center',backgroundColor:'#fff'}}>
										<Col><Text style={{fontSize:15}}>Cuti diambil</Text></Col>
										<Col>
											<View style={{alignSelf: 'flex-end',}}>
												<Button small primary><Text style={{fontSize:15}}>0</Text></Button>
											</View>
										</Col>
									</Grid>
									</View>
									<View style={{flex: 1,  justifyContent: 'center', alignItems: 'center',padding:20}}>
										<Grid style={{justifyContent: 'center', alignItems: 'center'}}>
											<Col><Text style={{fontSize:15,color:'white'}}>Sisa cuti</Text></Col>
											<Col>
												<View style={{alignSelf: 'flex-end',}}>
													<Button small danger><Text style={{fontSize:15}}>12</Text></Button>
												</View>
											</Col>
										</Grid>
									</View>
								</Body>
							</CardItem>
						</Card>
					</Col>
				</Grid>
				<Grid style={{justifyContent: 'center', alignItems: 'center',backgroundColor:'#fff',marginBottom:10}}>
					<Col style={{padding:20}}>
						<Text>Riwayat</Text>
						<List dataArray={items}
							renderRow={(item) =>
								<ListItem>
									<Grid style={{justifyContent: 'center', alignItems: 'center'}}>
										<Col>
											<Grid>
												<Row><Text>{item}</Text></Row>
												<Row><Text>Ciamis jawa barat</Text></Row>
											</Grid>
										</Col>
										<Col>
											<View style={{alignSelf: 'flex-end',}}>
												<Button small primary><Text style={{fontSize:15}}>5 Hari</Text></Button>
											</View>
										</Col>
									</Grid>
								</ListItem>
							}>
						</List>
					</Col>
				</Grid>
			
			</Content>
			<Footer style={styles.head}>
				<Body style={{alignSelf: 'flex-start',padding:15}}>
					<Title>Pengajuan Cuti</Title>
				</Body>
				<Right>
					<Button transparent onPress={() => this.props.navigation.navigate("Inputcuti")}>
						<Icon name="ios-arrow-forward" style={{color:'white',fontSize:40}}/>
					</Button>
				</Right>
			</Footer>
		</Container>
		);
	}
}
export default Cuti;