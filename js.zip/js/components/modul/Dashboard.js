import React, { Component } from "react";
import { TouchableOpacity,View,Image } from "react-native";
import { connect } from "react-redux";
import BlankPage2 from "../blankPage2";
import Kampret from "../blankPage2";
import DrawBar from "../DrawBar";
import { DrawerNavigator, NavigationActions } from "react-navigation";
import {
  Container,
  Header,
  Title,
  Content,
  Text,
  Button,
  Icon,
  Left,
  Body,Card, CardItem,
  Right,Badge
} from "native-base";
import { Grid, Row,Col } from "react-native-easy-grid";

import { setIndex } from "../../actions/list";
import { openDrawer } from "../../actions/drawer";
import styles from "./styles";

class Dashboard extends Component {
	static navigationOptions = {
		header: null
	};
	render() {
    return (
		<Container style={styles.bgpage}>
			<Header>
				<Left>
					<Button transparent onPress={() => this.props.navigation.goBack()}>
						<Icon name="ios-arrow-back" />
					</Button>
				</Left>
				<Body>
					<Title>Dashboard</Title>
				</Body>
				<Right />
			</Header>
			<Content>
				<Grid style={styles.margin_bottom}>
					<Col>
						<View style={styles.box_white_sec}>
							<Grid style={{paddingLeft:25}}>
								<Col style={{width:30}}><Icon name='ios-calendar-outline' style={{color:'#3e626e'}}/></Col>
								<Col><Text style={{fontSize:20}}>Total Absensi Hari ini</Text></Col>
							</Grid>
							<Grid style={{padding:20,flex:0}}>
								<Col>
									<View style={styles.box_green}>
										<View style={styles.center}>
											<Text style={{fontSize:15,color:'white'}}>25</Text>
											<Text style={{fontSize:15,color:'white'}}>Masuk</Text>
										</View>
									</View>
								</Col>
								<Col>
									<View style={styles.box_blue}>
										<View style={styles.center}>
											<Text style={{fontSize:15,color:'white'}}>0</Text>
											<Text style={{fontSize:15,color:'white'}}>Telat</Text>
										</View>
									</View>
								</Col>
								<Col>
									<View style={styles.box_red}>
										<View style={styles.center}>
											<Text style={{fontSize:15,color:'white'}}>0</Text>
											<Text style={{fontSize:15,color:'white'}}>Tidak Masuk</Text>
										</View>
									</View>
								</Col>
							</Grid>
						</View>
					</Col>
				</Grid>
			</Content>
		</Container>
		);
	}
}
export default Dashboard;