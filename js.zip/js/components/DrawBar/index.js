import React from "react";
import { AppRegistry, Image, TouchableOpacity } from "react-native";
import {
  Button,
  Text,
  Container,
  List,
  ListItem,
  Content,
  Icon
} from "native-base";

const routes = [
	{name: 'Home',icon: 'home',ref:'Home'},
	{name: 'Dashboard',icon: 'md-grid',ref:'Dashboard'},
	{name: 'Notifikasi',icon: 'md-phone-portrait',ref:'Notifikasi'},
	{name: 'Layanan Umum',icon: 'md-document',ref:'Layanan'},
	{name: 'Cuti',icon: 'md-calendar',ref:'Cuti'},
	{name: 'Profil',icon: 'md-person',ref:'Profile'},
	{name: 'Keluar',icon: 'md-exit',ref:'Keluar'}
]	
export default class DrawBar extends React.Component {
  static navigationOptions = {
    header: null
  };
  render() {
    return (
      <Container>
        <Content>
          <Image
            source={require("../../../images/profile.png")}
            style={{
				alignSelf: 'stretch',
				justifyContent: "center",
                alignItems: "center",
				width:'100%'
			}}>
            <TouchableOpacity
              style={{
                height: 120,
                alignSelf: "stretch",
                justifyContent: "center",
                alignItems: "center"
              }}
              onPress={() => this.props.navigation.navigate("DrawerClose")}>
              <Image
                square
                style={{ height: 80, width: 70 }}
                source={{
                  uri: "https://github.com/GeekyAnts/NativeBase-KitchenSink/raw/react-navigation/img/logo.png"
                }}
              />
            </TouchableOpacity>
          </Image>
          <List
            dataArray={routes}
            renderRow={data => {
              return (
                <ListItem
                  button
                  onPress={() => this.props.navigation.navigate(data.ref)}>
					<Icon name={data.icon} style={{ marginRight: 30}}/>
					<Text>{data.name}</Text>
                </ListItem>
              );
            }}
          />
		  
        </Content>
      </Container>
    );
  }
}
